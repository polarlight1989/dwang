<?php
 
return array(
	//'配置项'=>'配置值'
	'PUBLIC_URL'=>'/core/Public/',
);
