<?php if (!defined('THINK_PATH')) exit();?><div class="page-footer-inner"> 2016 &copy; Power By  <?php echo C("PowerBy");?> </div>
<div class="scroll-to-top">
    <i class="icon-arrow-up"></i>
</div>