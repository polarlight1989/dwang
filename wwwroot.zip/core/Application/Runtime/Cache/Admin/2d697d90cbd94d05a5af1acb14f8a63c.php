<?php if (!defined('THINK_PATH')) exit();?><div ng-page-nav ></div>
<h1 class="page-title"> {{title}}  </h1>

<div class="row">
	<div class="col-md-12">
		<div class="portlet light portlet-fit portlet-form bordered">
			<div class="portlet-title">
                                        <div class="caption">
                                            <i class=" icon-layers font-green"></i>
                                            <span class="caption-subject font-green sbold uppercase">{{txtMode}}</span>
                                        </div>
                                         
                                    </div>
									<div class="portlet-body">
                                        <!-- BEGIN FORM-->
                                        <form action="#" class="form-horizontal"  >
                                            <div class="form-body" >
                                                <div fg-input-text ng-model="formData.name" title='组名称' text='用户组名称'></div>
                                                <div fg-input-textarea ng-model="formData.intro" title='简介' text='简介'></div> 
												 
											</div>
											 
											<div class="form-actions">
                                                <div class="row">
											 
                                                    <div class="col-md-offset-3 col-md-6">
                                                        <button type="button" class="btn default">返回</button>
                                                        <button type="button" class="btn blue" ng-click='subForm()'>提交</button>
                                                    </div>
                                                </div>
                                            </div>
		</div>
	</div> 
</div>