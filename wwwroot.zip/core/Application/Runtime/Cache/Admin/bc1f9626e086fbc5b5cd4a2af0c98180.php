<?php if (!defined('THINK_PATH')) exit();?><div ng-page-nav ></div>
<div class="row">
	  
	<div  ng-data-table columns="columns" funcs='funcs' title='{{title}}'  mod='mod' oper='oper' actions='actions' postparams='postparams'></div>
 
 
</div>