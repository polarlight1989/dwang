<?php if (!defined('THINK_PATH')) exit();?><mbx id='<?php echo ($catalog_id); ?>'></mbx>

<div style='padding:.3rem' ng-controller='single' ng-bind-html="data.content|trusted"> 
</div>