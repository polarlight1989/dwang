<?php if (!defined('THINK_PATH')) exit();?><div class='mbx'>
	<a href=''>企业概况<i></i></a><a href=''>企业概况<i></i></a>
</div>

<div style='padding:.3rem' ng-bind-html="data.content|trusted"> 
</div>