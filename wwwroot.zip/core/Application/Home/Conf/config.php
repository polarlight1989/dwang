<?php
return array(
	//'配置项'=>'配置值'
	'API_KEY'=>'E20A5DBFB2866745496AB1262FBFD40B'
);